"""Interface utilisateur Streamlit."""

